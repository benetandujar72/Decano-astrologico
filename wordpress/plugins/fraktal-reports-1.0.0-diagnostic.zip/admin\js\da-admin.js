/**
 * Scripts del Panel de Administración
 *
 * @package Decano_Astrologico
 * @since 1.0.0
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        console.log('Decano Admin loaded');
    });

})(jQuery);
